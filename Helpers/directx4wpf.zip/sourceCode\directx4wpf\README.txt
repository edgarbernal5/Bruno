Solution Content:
=================
- SharpDX.WPF:
Core WPF to DirectX utility class, more:
http://galador.net/codeblog/post/2011/05/14/Introducing-DirectX-to-WPF.aspx

- Week00:
A quick and dirty app that show all supported DirectX interfaces up and running

- Week00ToFile:
A quick and dirty demo app to show how to render some DirectX and save it to a file

- Week01D3D11Tutorials:
MSDN Tutorials in C#, from:
http://msdn.microsoft.com/en-us/library/ff729717(v=VS.85).aspx

- Week02Samples:
More samples (more than 1 week of coding though...)
Show more "real life" usage of DirectX...


Links:
======
SharpDX
http://code.google.com/p/sharpdx/
http://code4k.blogspot.com/
NShader VS2010 extension: syntax syntax highlighting for HLSL
http://nshader.codeplex.com/

General Interop:
http://msdn.microsoft.com/en-us/library/115F7A2F-D422-4605-AB36-13A8DD28142A(v=vs.100,d=lightweight).aspx
http://pinvoke.net/

HLSL
http://msdn.microsoft.com/en-us/library/bb509561%28VS.85%29.aspx
http://msdn.microsoft.com/en-us/library/bb509615(v=VS.85).aspx
http://msdn.microsoft.com/en-us/library/bb509635(v=VS.85).aspx

Quaternions
http://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation
http://www.itk.org/CourseWare/Training/QuaternionsI.pdf
http://www.cprogramming.com/tutorial/3d/quaternions.html
http://www.euclideanspace.com/maths/algebra/realNormedAlgebra/quaternions/index.htm


Learning Resources
http://msdn.microsoft.com/en-us/library/ff729717(v=VS.85).aspx
http://knol.google.com/k/hlsl-shaders
http://learningwebgl.com/blog/?page_id=1217?
http://www.xbdev.net/directx3dx/directx3dx.php
http://www.gamedev.net/forum/10-directx-and-xna/

http://legalizeadulthood.wordpress.com/category/computers/programming/directx/direct3d-programming-tips/
http://www.xmission.com/~legalize/book/download/

Fur:
http://www.xbdev.net/directx3dx/specialX/Fur/index.php


Meshellator and other by Roasted Amoeba:
http://www.roastedamoeba.com/blog/archive/2011/02/22/meshellator---open-source-d-asset-import
http://www.roastedamoeba.com/blog/archive/2010/12/09/xbuilder-v-released
http://www.roastedamoeba.com/blog/archive/2011/02/23/dotwarp---server-side-d-renderer-for
https://github.com/roastedamoeba/nexus

TODO:
=====
- ContentStream: ContentLoader => AsyncLoader => ContentStream10

- detect which interface the current PC support and why the heck the D3D11.Device constructor takes multiple feature level?
- Week00ToFile, try Warp driver, try on lesser computer.. do not crash!
- precompile fx/hsls/etc... files?

- DirectX samples (future ideas already as commented in the XAML)
- Nexus & Meshellator: models loading and manipulating, 
DXControl with selected camera control? (view,model, etc..) from keyboard, little preview, etc..






=== SharpDX bugs & Notes ===

1.
SharpDX.DXGI.Surface.Map() (old code commented)
---
        public DataRectangle Map(MapFlags flags)
		{
			MappedRect mappedRect;
			Map(out mappedRect, (int) flags);
			var desc = Description;
			//int size = (int)(FormatHelper.SizeOfInBytes(desc.Format) * desc.Width * desc.Height);	   
			int size = (int)(mappedRect.Pitch * desc.Height);	   
			var canRead = (flags & MapFlags.Read) != 0;             
			var canWrite = (flags & MapFlags.Write) != 0;             
			return new DataRectangle(mappedRect.Pitch, new DataStream(mappedRect.PBits, size, canRead, canWrite));              
		}

---
2.
SharpDX.Direct3D11.DeviceContext.MapSubresource
---
        //public DataBox MapSubresource(Resource resource, int subresource, int sizeInBytes, MapMode mode, MapFlags flags)         
        public DataBox MapSubresource(Resource resource, int subresource, MapMode mode, MapFlags flags)         
		{             
			unsafe             
			{
				MappedSubResource mappedSubResource;
				Map(resource, subresource, mode, flags, out mappedSubResource);
				//return new DataBox(mappedSubResource.RowPitch, mappedSubResource.DepthPitch,
				//                   new DataStream((void*)mappedSubResource.PData, sizeInBytes, true, true, false));
				return new DataBox(mappedSubResource.RowPitch, mappedSubResource.DepthPitch,    
					new DataStream((void*)mappedSubResource.PData, mappedSubResource.DepthPitch, true, true, false));
			}         
		}

-- 
3.
ComObject, incorrect dispose implementation (fix below) 
but can't be used due to out of scope object holding critical objects
i.e. if I set the correct pattern, some dead useful object will crash the app on the next GC

~ComObject()
{
	Dispose(false);
}
 
/// <summary>
/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
/// </summary>
public void Dispose()
{
	GC.SuppressFinalize(this);
	Dispose(true);
}
 
protected virtual void Dispose(bool disposing)
{	// always release, it's a native resource!
	Release();
}

