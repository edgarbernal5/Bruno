using System.Collections.Generic;

namespace Nexus
{
	public class Point2DCollection : List<Point2D>
	{
	}
}