namespace Meshellator.Importers.LightwaveObj.Objects
{
	public enum FaceType
	{
		Triangles,
		Quads
	}
}