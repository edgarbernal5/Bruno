namespace Meshellator.Importers.LightwaveObj.Objects.Parsers
{
	public class DefaultParser : LineParser
	{
		public override void Parse()
		{

		}

		public override void IncorporateResults(WavefrontObject wavefrontObject)
		{
			
		}
	}
}