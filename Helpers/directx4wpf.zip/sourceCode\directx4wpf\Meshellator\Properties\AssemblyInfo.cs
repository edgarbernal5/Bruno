﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Meshellator")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCulture("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("1ab5840e-5e00-4708-b6b8-1628a903a1e0")]


[assembly: AssemblyConfiguration("Retail")]
[assembly: AssemblyCompany("Tim Jones")]
[assembly: AssemblyProduct("Meshellator")]
[assembly: AssemblyCopyright("Copyright ©2011 Tim Jones")]
[assembly: AssemblyTrademark("roastedamoeba.com")]
[assembly: ComVisible(false)]


[assembly: AssemblyFileVersion("1.0.3.0")]
[assembly: AssemblyVersion("1.0.3.0")]
