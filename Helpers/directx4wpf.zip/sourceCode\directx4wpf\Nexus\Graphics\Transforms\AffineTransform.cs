﻿namespace Nexus.Graphics.Transforms
{
	public abstract class AffineTransform : Transform3D
	{
	}
}
