namespace Nexus
{
	public struct Sphere
	{
		public Point3D Center;
		public float Radius;
	}
}