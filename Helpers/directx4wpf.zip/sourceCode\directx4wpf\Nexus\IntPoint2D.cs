namespace Nexus
{
	public struct IntPoint2D
	{
		public int X;
		public int Y;

		public IntPoint2D(int x, int y)
		{
			X = x;
			Y = y;
		}
	}
}