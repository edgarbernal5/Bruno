namespace Meshellator.Importers.Nff.Parsers
{
	public class CommentParser : LineParser
	{
		public override void Parse(ParserContext context, Scene scene, string[] words)
		{
			// Do nothing.
		}
	}
}