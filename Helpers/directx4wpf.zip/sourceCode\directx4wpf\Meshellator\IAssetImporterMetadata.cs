namespace Meshellator
{
	public interface IAssetImporterMetadata
	{
		string Extension { get; }
		string Name { get; }
	}
}