namespace Nexus.Graphics.Transforms
{
	public abstract class Rotation
	{
		public abstract Quaternion Value
		{
			get;
		}
	}
}