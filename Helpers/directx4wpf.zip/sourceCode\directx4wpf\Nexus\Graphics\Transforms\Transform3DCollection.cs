using System.Collections.Generic;

namespace Nexus.Graphics.Transforms
{
	public class Transform3DCollection : List<Transform3D>
	{
		
	}
}