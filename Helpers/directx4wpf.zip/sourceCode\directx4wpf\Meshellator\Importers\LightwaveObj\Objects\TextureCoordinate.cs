namespace Meshellator.Importers.LightwaveObj.Objects
{
	public class TextureCoordinate
	{
		public float U { get; set; }
		public float V { get; set; }
		public float W { get; set; }
	}
}