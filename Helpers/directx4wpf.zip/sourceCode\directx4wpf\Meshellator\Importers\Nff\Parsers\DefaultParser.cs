namespace Meshellator.Importers.Nff.Parsers
{
	public class DefaultParser : LineParser
	{
		public override void Parse(ParserContext context, Scene scene, string[] words)
		{
			// Do nothing.
		}
	}
}