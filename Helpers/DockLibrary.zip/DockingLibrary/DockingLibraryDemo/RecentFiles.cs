using System;
using System.Collections.Generic;
using System.Text;

namespace DockingLibraryDemo
{
    class RecentFiles : System.Collections.ObjectModel.ObservableCollection<RecentFile>
    {

        public RecentFiles()
        {
        }

    }
}
