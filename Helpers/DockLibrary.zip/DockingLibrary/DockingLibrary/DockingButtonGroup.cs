using System;
using System.Collections.Generic;
using System.Text;

namespace DockingLibrary
{
    public class DockingButtonGroup
    {
        public readonly List<DockingButton> Buttons = new List<DockingButton>();
        public System.Windows.Controls.Dock Dock; 
    }
}
